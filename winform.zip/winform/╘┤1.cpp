int pin = 2;
int ec = 4;
int tr = 3;


boolean sendFlag = false;//�Ƿ�����ͨ�����ڷ�������
boolean readComplete = false;//�Ƿ���ɶ�ȡ��������
String serialString = "";//�������ݻ����ַ�
void setup() {
    pinMode(pin, OUTPUT);
    Serial.begin(9600);
    serialString.reserve(200);//��ʼ���ַ���
}

void loop()
{
    while (Serial.available())
    {
        char c = Serial.read();
        if (c == 'A')
        {
            Doit();
        }
    }

    void DoTheRecive() {
        if (readComplete)
        {
            Serial.print(serialString);
            if (serialString == "start") {
                sendFlag = true;
            }
            else if (serialString == "stop") {
                sendFlag = false;
            }
            serialString = "";
            readComplete = false;
        }
        if (sendFlag)
        {
            digitalWrite(pin, HIGH);
            Serial.print("The PIN IS ON");
            delay(5000);
        }
    }
    void Doit() {
        digitalWrite(pin, HIGH);
        Serial.print("The distance is:");
        unsigned int kk;
        kk = Echo(ec, tr);
        Serial.print(kk);
        delay(10);
    }

    int Echo(char ec, char tr)
    {
        int dist;
        pinMode(ec, INPUT);
        //digitalWrite(ec,HIGH);
        pinMode(tr, OUTPUT);
        digitalWrite(tr, HIGH);
        delayMicroseconds(12);
        digitalWrite(tr, LOW);
        dist = pulseIn(ec, HIGH);
        dist = dist / 58;
        return(dist);
    }
    void serialEvent() //�����¼������������ο�:http://arduino.cc/en/Tutorial/SerialEvent
    {
        while (Serial.available()) //�ο�://arduino.cc/en/Serial/Available
        {
            char inChar = (char)Serial.read();
            if (inChar != '\n') //�Ի��з���Ϊ��ȡ������־
            {
                serialString += inChar;
            }
            else
            {
                readComplete = true;
            }
        }
    }
