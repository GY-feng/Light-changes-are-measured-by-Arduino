﻿namespace 光线的线性变化wf
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.but_draw = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.but_help = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tex_showcom = new System.Windows.Forms.TextBox();
            this.tex_getcom = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.but_close = new System.Windows.Forms.Button();
            this.but_start = new System.Windows.Forms.Button();
            this.but_excle = new System.Windows.Forms.Button();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.txt_sharttime = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // chart1
            // 
            this.chart1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.chart1.BorderSkin.BackColor = System.Drawing.Color.White;
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            this.chart1.Dock = System.Windows.Forms.DockStyle.Fill;
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(275, 0);
            this.chart1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            series1.ToolTip = "\"#VALX,#VALY\"";
            series1.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time;
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(1536, 829);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            this.chart1.Click += new System.EventHandler(this.chart_Click);
            // 
            // but_draw
            // 
            this.but_draw.Location = new System.Drawing.Point(5, 60);
            this.but_draw.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.but_draw.Name = "but_draw";
            this.but_draw.Size = new System.Drawing.Size(83, 52);
            this.but_draw.TabIndex = 1;
            this.but_draw.Text = "画图";
            this.but_draw.UseVisualStyleBackColor = true;
            this.but_draw.Click += new System.EventHandler(this.but_draw_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txt_sharttime);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.but_help);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.tex_showcom);
            this.panel1.Controls.Add(this.tex_getcom);
            this.panel1.Controls.Add(this.flowLayoutPanel1);
            this.panel1.Controls.Add(this.but_close);
            this.panel1.Controls.Add(this.but_start);
            this.panel1.Controls.Add(this.but_excle);
            this.panel1.Controls.Add(this.but_draw);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(275, 829);
            this.panel1.TabIndex = 2;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // but_help
            // 
            this.but_help.Location = new System.Drawing.Point(36, 756);
            this.but_help.Margin = new System.Windows.Forms.Padding(4);
            this.but_help.Name = "but_help";
            this.but_help.Size = new System.Drawing.Size(171, 58);
            this.but_help.TabIndex = 3;
            this.but_help.Text = "使用提示";
            this.but_help.UseVisualStyleBackColor = true;
            this.but_help.Click += new System.EventHandler(this.but_help_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(2, 239);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 15);
            this.label2.TabIndex = 13;
            this.label2.Text = "反馈行";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 115);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 15);
            this.label1.TabIndex = 12;
            this.label1.Text = "输入端口";
            // 
            // tex_showcom
            // 
            this.tex_showcom.Location = new System.Drawing.Point(-3, 256);
            this.tex_showcom.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tex_showcom.Multiline = true;
            this.tex_showcom.Name = "tex_showcom";
            this.tex_showcom.Size = new System.Drawing.Size(275, 453);
            this.tex_showcom.TabIndex = 11;
            this.tex_showcom.TextChanged += new System.EventHandler(this.tex_showcom_TextChanged);
            // 
            // tex_getcom
            // 
            this.tex_getcom.Location = new System.Drawing.Point(0, 132);
            this.tex_getcom.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tex_getcom.Multiline = true;
            this.tex_getcom.Name = "tex_getcom";
            this.tex_getcom.Size = new System.Drawing.Size(269, 38);
            this.tex_getcom.TabIndex = 10;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Location = new System.Drawing.Point(133, 38);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(8, 8);
            this.flowLayoutPanel1.TabIndex = 9;
            // 
            // but_close
            // 
            this.but_close.Enabled = false;
            this.but_close.Location = new System.Drawing.Point(88, 2);
            this.but_close.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.but_close.Name = "but_close";
            this.but_close.Size = new System.Drawing.Size(83, 52);
            this.but_close.TabIndex = 8;
            this.but_close.Text = "关闭";
            this.but_close.UseVisualStyleBackColor = true;
            this.but_close.Click += new System.EventHandler(this.but_showthecom_Click);
            // 
            // but_start
            // 
            this.but_start.Location = new System.Drawing.Point(3, 2);
            this.but_start.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.but_start.Name = "but_start";
            this.but_start.Size = new System.Drawing.Size(83, 52);
            this.but_start.TabIndex = 7;
            this.but_start.Text = "开始";
            this.but_start.UseVisualStyleBackColor = true;
            this.but_start.Click += new System.EventHandler(this.button6_Click);
            // 
            // but_excle
            // 
            this.but_excle.Location = new System.Drawing.Point(88, 60);
            this.but_excle.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.but_excle.Name = "but_excle";
            this.but_excle.Size = new System.Drawing.Size(83, 52);
            this.but_excle.TabIndex = 6;
            this.but_excle.Text = "导出数据为EXCLE";
            this.but_excle.UseVisualStyleBackColor = true;
            this.but_excle.Click += new System.EventHandler(this.but_excle_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(198, 15);
            this.label3.TabIndex = 14;
            this.label3.Text = "X轴开始的时间，格式:16:XX";
            // 
            // txt_sharttime
            // 
            this.txt_sharttime.Location = new System.Drawing.Point(0, 189);
            this.txt_sharttime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_sharttime.Multiline = true;
            this.txt_sharttime.Name = "txt_sharttime";
            this.txt_sharttime.Size = new System.Drawing.Size(269, 38);
            this.txt_sharttime.TabIndex = 15;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1811, 829);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Button but_draw;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button but_close;
        private System.Windows.Forms.Button but_start;
        private System.Windows.Forms.Button but_excle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tex_showcom;
        private System.Windows.Forms.TextBox tex_getcom;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Button but_help;
        private System.Windows.Forms.TextBox txt_sharttime;
        private System.Windows.Forms.Label label3;
    }
}

