﻿using ClosedXML.Excel;
using System;
using System.Drawing;
using System.IO.Ports;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Threading;
#region//修改记录：
/*
4.21：完成串口通讯
4.22：完成下位机向上位机的数据上传操作，完成EXCLE表格的导出操作，完成图表的操作
4.23：暂时取消的EXCLE表格的导出功能，增加了在传递数据的同时，多线程地对图表进行修改
4.24：取消了画图功能的多线程，后加上锁保留多线程，测试中锁了个寂寞，取消！！！
4.25：暂时开放导出为Excle格式，但是有BUG；
4.26：整理代码，修复EXCLE导出的BUG，使之能正常运行（错误提示：EXCLE在本机用WPS成功运行，在其他机的EXCLE2007打开错误）
4.27: 添加关闭串口的功能，并且考虑到在将Arduino接收到的数据可能是string类型，而不能转换为double，增加了正则表达式对是否为数字进行了判断
5.15: 优化了界面(新加按钮能否被按下）
5.16：改进了Excle的保存方案，使之能够保存在当前目录下,将图标的charttype属性改为Spline类型，使之绘制出平滑的图表.改变图表的X轴类型，使之绘制出时间相关的数据
 */
#endregion
namespace 光线的线性变化wf
{
    public partial class Form1 : Form
    {
        #region//初始化一些数据
        //这里面的代码乱得像一坨屎，也难改了
        public double[] a = new double[2000];     //定义数组存储数据
        //public double[] a = { 1, 2, 3, 64, 23, 64, 32, 45, 21, 42, 53, 75, 35, 35, 32, 52 };//TEST

        public int count = 0;
        public string[] command = { "start" };
        SerialPort serialPort = new SerialPort();
        #endregion
        #region//对图表的操作
        /// <summary>
        /// 设置图标的基本信息（如字体，横纵坐标等）
        /// </summary>
        public void SetTheChart()
        {
            chart1.ChartAreas[0].AxisX.Title = "时间/1min";
            chart1.ChartAreas[0].AxisY.Title = "光强/lx";


            //chart1.ChartAreas[0].XvalueType = DateTime.Now;
            chart1.ChartAreas[0].AxisX.TitleFont = new Font("宋体", 12F);
            chart1.ChartAreas[0].AxisY.TitleFont = new Font("宋体", 12F);
        }
        /// <summary>
        /// 绘制图表
        /// </summary>
        public void DrawTheChart()
        {
            chart1.Series[0].Points.Clear();//清空数据
            DateTime dt;
            if (txt_sharttime.Text=="")
            {
                dt = DateTime.Now;
                MessageBox.Show("X轴初始值将以当前的时间作为初始值");
            }
            else
            {
                dt = Convert.ToDateTime(txt_sharttime.Text);
            }
            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] != 0)
                {
                    chart1.Series[0].Points.AddXY(dt, a[i]);
                    dt=dt.AddMinutes(1);               
                }
            }
        }
        #endregion
        #region//对串口的操作
        /// <summary>
        /// 对所传进来的SerialPort的对象进行基本的初始化操作
        /// </summary>
        /// <param name="serialPort"></param>
        /// <returns></returns>
        /// 
        void port_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            this.RefreshInfoTextBox();
        }
        public SerialPort SetPort(SerialPort serialPort)
        {
            tex_showcom.Text = "您选择的端口名字为：" + Environment.NewLine + serialPort.PortName;
            serialPort.BaudRate = 9600;
            serialPort.Encoding = Encoding.ASCII;
            bool a = serialPort.IsOpen;
            try
            {
                serialPort.Open();

            }
            catch (Exception)
            {
                MessageBox.Show("串口打开错误");

            }
            if (serialPort.IsOpen)
            {
                return serialPort;//将已经被打开的串口返回主函数
            }
            else
            {
                MessageBox.Show("IsOpen属性为false，请检查");
                return serialPort;
            }
        }
        private string ReadSerialData()
        {
            string value = "";
            try
            {
                if (serialPort != null && serialPort.BytesToRead > 0)
                {
                    value = serialPort.ReadExisting();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("读取串口数据发生错误：" + ex.Message, "提示信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            return value;
        }
        //添加正则表达式类Regex
        public static bool IsInt(string x)
        {
            const string pattern = "^[0-9]*$";
            Regex rx = new Regex(pattern);
            bool IsDigit = rx.IsMatch(x);
            return IsDigit;//是数字返回true,不是返回false
        }
        private void RefreshInfoTextBox()
        {
            string value = this.ReadSerialData();
            Action<string> setValueAction = text => this.tex_showcom.Text += text;
            //4.24取消多线程 
            // Action action1 = DrawTheChart;
            //4.24取消多线程
            //Task task3 = new Task(action1);
            if (this.tex_showcom.InvokeRequired)
            {
                try
                {
                    bool isint = true;
                    if (isint)
                    {
                        a[count] = 0;
                        a[count] = Convert.ToDouble(value);
                        count++;
                    }
                }
                catch (Exception)
                {

                    MessageBox.Show("数据返回出现错误！！！请注意，请在开始使用之前要使得测试机位于正常！！！点击确定继续执行");
                }
                // lock (looker1)
                //{
                this.tex_showcom.Invoke(setValueAction, value);
                //// //4.24加上线程锁，本函数在被执行的时候，其他线程无法调用我!!!
                // }
                //// //4.24取消多线程
                // Control.CheckForIllegalCrossThreadCalls = false;//线程开始的时候来上这么一句不会报错，VS2003不报错，VS2005后开始报错
                // Thread.Sleep(100);
                // lock (looker2)
                //{
                //   task3.Start();
                //}

            }
            else
            {
                setValueAction(value);
            }
        }
        /// <summary>
        /// 一些命令
        /// </summary>
        /// <param name="serialPort"></param>
        public void Command(SerialPort serialPort)
        {
            if (serialPort != null && serialPort.IsOpen)
            {
                serialPort.WriteLine("A");
            }
            else
            {
                MessageBox.Show("向串口打开PUT IN错误");
            }
            tex_showcom.Text = "";//Clear文本框
            tex_showcom.Text = tex_showcom.Text + Environment.NewLine +
                "start的命令已经被传送" + Environment.NewLine;
        }
        #endregion
        #region//很多按钮的操作
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            string[] portsnames = SerialPort.GetPortNames();
            string theports = "";
            for (int i = 0; i < portsnames.Length; i++)
            {
                theports = (portsnames[i]) + "、" + theports;
            }
            tex_showcom.Text = "现在能用的端口有" +
               Environment.NewLine + theports +
               Environment.NewLine + "请在命令行里面输入您所想使用的端口，注意不要写错";
        }
        //public void 
        private void chart_Click(object sender, EventArgs e)
        {

        }
        private void but_draw_Click(object sender, EventArgs e)
        {

            // ProcessingTheDate();
            SetTheChart();
            DrawTheChart();
        }
        private void but_excle_Click(object sender, EventArgs e)
        {
            XLWorkbook workbook = new XLWorkbook();
            Excel excel = new Excel();
            excel.SetWork(workbook, a, count);
        }

        private void but_help_Click(object sender, EventArgs e)
        {
            MessageBox.Show("使用须知：" + Environment.NewLine + "作者：枫" 
                + Environment.NewLine + "如果程序弹窗报错，若检查无误后，点击确定继续执行" + Environment.NewLine +
                "本程序启动的时候，向单片机发送字符“a”，然后执行接收数据的命令" + Environment.NewLine +
                "如果使用保存为Excle功能，EXCLE文件将会保存在当前程序运行的目录之下" +
                Environment.NewLine + "并且在保存前，请将该文件导出，否则会报错或者覆盖文件" +
                Environment.NewLine + "注意：本程序目前最多只能接收1000（可拓展）个数据" + Environment.NewLine +
                "注意：数据为0的数据将不被写入EXCLE之中"+Environment.NewLine +
                "图表功能中X轴的初始坐标可以设定，若不设定，则以当前时间做初始值");
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)//BUT_START不知道为什么名字改不了
        {
            but_start.Enabled = false;
            but_close.Enabled = true;
            try
            {
                serialPort.PortName = tex_getcom.Text;
                serialPort = SetPort(serialPort);
                MessageBox.Show("串口已经配置完成,开始执行命令");
                serialPort.DataReceived += port_DataReceived;
                Command(serialPort);
            }
            catch (Exception)
            {

                MessageBox.Show("请输入要操作的端口");
            }
        }

        private void but_showthecom_Click(object sender, EventArgs e)
        {
            #region//旧功能
            /*
                      //tex_showcom.Text = "";//清空文本框
            //for (int i = 0; i < command.Length; i++)
            //{
            //    tex_showcom.Text = command[0] +
            //    Environment.NewLine + command[1];
            //}
          */
            #endregion
            but_close.Enabled = false;
            but_start.Enabled = true;
            try
            {
                if (serialPort == null)
                {
                    MessageBox.Show("目前没有被打开的串口，请打开串口再尝试");
                }
                else
                {
                    serialPort.WriteLine("B");
                    serialPort.Close();
                    MessageBox.Show("串口已经关闭");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("当前没有串口被打开，关闭错误");
            }
        }

        private void tex_showcom_TextChanged(object sender, EventArgs e)
        {

        }
        #endregion
    }
    public class Excel
    {       /// <summary>
            /// 对Excle图表的操作
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
        public void SetWork(XLWorkbook workbook, double[] a, int count)
        {

            workbook.AddWorksheet("灯光的线性变化");
            IXLWorksheet sheet = workbook.Worksheet("灯光的线性变化");//row行，line列
            sheet.Cell(1, 1).Value = "第X分钟";
            sheet.Cell(1, 2).Value = "lx值";
            for (int i = 2; i < a.Length + 2; i++)
            {
                if (a[i - 2] != 0)//加上这行代码以实现数据为0的数据不被写入EXCLE之中
                {
                    string num = Convert.ToString(a[i - 2]);
                    sheet.Cell(i, 1).Value = Convert.ToString(i - 1);
                    sheet.Cell(i, 2).Value = num;
                }
            }
            try
            {

                string xlsxname = (DateTime.Today).ToString()+ "灯光线性变化.xlsx";
                workbook.SaveAs(@"灯光线性变化.xlsx");
                MessageBox.Show("创建成功");
            }
            catch (Exception)
            {

                MessageBox.Show("Excle保存失败");
            }
        }

    }

}

